const express = require('express');
const router = express.Router();
const userController = require('../controllers/userController');

const { handleNewPurchase } = require('../controllers/purchaseController');
const db = require('../db');

router.post('/purchase', handleNewPurchase);
router.post('/Users', userController.createUser);
router.get('/Users/:id/earnings', async (req, res) => {
  const earnings = await db.getUserEarnings(req.params.id);
  res.json({ earnings }); 
});



module.exports = router;
