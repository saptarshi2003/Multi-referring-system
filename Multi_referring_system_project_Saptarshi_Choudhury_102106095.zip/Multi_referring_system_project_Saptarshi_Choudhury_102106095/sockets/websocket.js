const WebSocket = require('ws');
const clients = {};

function initWebSocket(server) {
  const wss = new WebSocket.Server({ server });

  wss.on('connection', (ws, req) => {
    const userId = new URL(req.url, `http://${req.headers.host}`).searchParams.get('userId');
    if (userId) clients[userId] = ws;

    ws.on('close', () => delete clients[userId]);
  });
}

function sendEarningNotification(userId, amount, fromUser, level) {
  const ws = clients[userId];
  if (ws?.readyState === WebSocket.OPEN) {
    ws.send(JSON.stringify({ userId, amount, fromUser, level }));
  }
}

module.exports = { initWebSocket, sendEarningNotification };
