const mongoose = require('mongoose');

const userSchema = new mongoose.Schema({
  name: { type: String, required: true },
  email: { type: String, required: true, unique: true },
  referrals: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }],
  referrer: { type: mongoose.Schema.Types.ObjectId, ref: 'User', default: null },
  level: { type: Number, default: 0 }
}, { timestamps: true });

// 👇 Use this line only
module.exports = mongoose.models.User || mongoose.model('User', userSchema);
