const mongoose = require('mongoose');
const { Schema } = mongoose;

const purchaseSchema = new Schema({
  buyerId: { type: Schema.Types.ObjectId, ref: 'User' },
  amount: Number,
  createdAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model('Purchase', purchaseSchema);
